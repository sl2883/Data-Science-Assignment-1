# Imports
import sys
from pyspark.sql import SparkSession


def create_dataframe(filepath, format, spark):
    """
    Create a spark df given a filepath and format.

    :param filepath: <str>, the filepath
    :param format: <str>, the file format (e.g. "csv" or "json")
    :param spark: <str> the spark session

    :return: the spark df uploaded
    """
    spark_df = None

    return spark_df


def transform_nhis_data(nhis_df):
    """
    Transform df elements

    :param nhis_df: spark df
    :return: spark df, transformed df
    """
    transformed_df = None
    
    return transformed_df


def calculate_statistics(joined_df):
    """
    Calculate prevalence statistics

    :param joined_df: the joined df

    :return: None
    """
    pass


if __name__ == '__main__':

    brfss_file_arg = sys.argv[1]
    nhis_file_arg = sys.argv[2]
    save_output_arg = sys.argv[3]
    if save_output_arg == "True":
        output_filename_arg = sys.argv[4]
    else:
        output_filename_arg = None


    # Start spark session
    spark = SparkSession.builder.getOrCreate()

    # Stop spark session 
    spark.stop()

